package lab6_3;
import java.util.Random;
public class CityGrid {
    private int xCoor,yCoor,gridSize;
    private int x,y;
    public CityGrid(int x, int y){
        this.xCoor=x/2;
        this.x=x;
        this.yCoor=y/2;
        this.y=y;
        this.gridSize=x*y;
    }
    public void walk(){
        Random ran = new Random();
        int walk = ran.nextInt(4);
        switch(walk){
            case 0 : xCoor++;break;//ขวา
            case 1 : xCoor--;break;//ซ้าย
            case 2 : yCoor++;break;//ลง
            case 3 : yCoor--;break;//ขึ้น
        }
    }
    public boolean isInCity(){
        if ((xCoor<0 || xCoor>x) || (yCoor<0 || yCoor>y)){
            return false;
        }
        else{
            return true;
        }
    }
    public void reset(){
        xCoor=x/2;
        yCoor=y/2;
    }
}
