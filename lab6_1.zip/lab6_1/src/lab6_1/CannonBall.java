
package lab6_1;
public class CannonBall {
    private double initV,simS,simT;
    public static final double g = 9.81;
    public CannonBall(double v){
        initV = v;
    }
    public void simulatedFlight(){
        double v=initV;
        int i=1;
        while(v>=0){
            simS+=v*0.01;
            v-=g*0.01;
            simT+=0.01;
            if(i%100==0){
                System.out.print("Distance on "+i/100);
                System.out.printf(" sec: %.3f",simS);
                System.out.println();
            }
        i++;
        }
    }
    public double calculusFlight(double t){
        simS=-0.5*g*simT*simT+initV*simT;
        return simS;
    }
    public double getSimulatedTime(){
        return simT;
    }
    public double getSimulatedDistance(){
        return simS;
    }
}
