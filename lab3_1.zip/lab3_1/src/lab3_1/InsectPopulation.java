/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_1;
import java.util.Scanner;

public class InsectPopulation {
    public double insect;
    public InsectPopulation (int num){
        insect = num;
    }
    
    public void breed() {
         insect=2*insect;
    }
    public void spray() {
        insect=insect-(insect*0.1);
    }
    public double getNumInsect() {
        return insect;
    }
    
}
