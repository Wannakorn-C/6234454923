package lab5_2;


public class LineTester {
    public static void main(String[] args){
        Line I1 = new Line(-2,1,1,-2);
        Line I2 = new Line(-6,-2,-2,0);
        System.out.println("Are the two lines equals?: "+I1.equals(I2));
        System.out.println("Are the two lines parallel?: "+I1.isParallel(I2));
        System.out.println("Do the two lines intersect?: "+I1.isIntersect(I2));
        if (I1.isIntersect(I2)){
            System.out.printf("Point of intersection: %.2f,%.2f%n",I1.getIntersectionPoint(I2).getX(),I1.getIntersectionPoint(I2).getY());
            
    }
  }
}    