
package lab11_1;

import java.util.ArrayList;


public class SelfCheckOut implements SimpleQueue{
    ArrayList<Object> items =new ArrayList<Object>();
    private double amount;
    public SelfCheckOut(){
        
    }
    public void enqueue(Object o){
        Product p=(Product)o;
        items.add(p);
        System.out.println(p.getName()+" is added in queue");
    }
    public void dequeue(){
        Product p=(Product)items.get(0);
        amount+=p.getPrice();   
        items.remove(0);
            
        
    }
    public double getAmount(){
        return amount;
    }
}
    

             