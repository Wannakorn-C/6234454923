
package lab8_1;

public class Truck extends Car{
    private double M_weight;
    private double weight;
    public Truck(double gas,double efficiency,double M_weight,double weight){
      super(gas,efficiency) ;
      this.M_weight=M_weight;
      this.weight=weight;
      if(weight>M_weight){
          weight=M_weight;
      }
    }
    @Override
    public void drive(double distance){
        if(distance/getEfficiency()<getGas()){
            if(weight>=1 && weight<=10){
            setGas(getGas()-(distance/getEfficiency()+((distance/getEfficiency())*0.1)));
            }else if(weight>=11 && weight<=20){
            setGas(getGas()-(distance/getEfficiency()+((distance/getEfficiency())*0.2))); 
            }else{
            setGas(getGas()-(distance/getEfficiency()+((distance/getEfficiency())*0.3)));    
            }
        }else{
            System.out.println("You cannot drive too far,Please add gas");  
        }
    
    }
}
        
            
    
