
package lab8_2;

import java.util.ArrayList;


public class ChoiceQuestion extends Question {
    ArrayList<String> Choice =new ArrayList<String>();
    public ChoiceQuestion(String text){
        super(text);
    }
    public void addChoice(String choice,Boolean correct){
        Choice.add(choice);
        if (correct.equals(true)){
            setAnswer(Choice.indexOf(choice)+1+"");
        }      
    }
    public void display(){
        System.out.println(getText());
        for(int i=1;i<=Choice.size();i++){
            System.out.println(i+":"+Choice.get(i-1));
        }
    }
    public boolean checkAnswer(String response){
        if(!response.equals(getAnswer())){
            return false;
        }
        return true;
    }
}
    
    
    

