 
package lab8_2;


public class Question {
    private String text;
    private String answer;
    public Question(String text){
        this.text=text;
           
    }
    public void setText(String Question){
        text=Question;
    }
    public String getText(){
        return text;
    }
    public void setAnswer(String Answer){
        answer=Answer;
    }
    public String getAnswer(){
        return answer;
    }
    public boolean checkAnswer(String response){
        return answer.equals(response);    
            
    }
    public void display(){
        System.out.println(text);
    }
}
    
    
    


