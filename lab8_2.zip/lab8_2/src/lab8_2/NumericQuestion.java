
package lab8_2;


public class NumericQuestion extends Question {
    public NumericQuestion(String text){
        super(text);    
    }
    public boolean checkAnswer(String response){
        double num1=Double.parseDouble(response);
        double num2=Double.parseDouble(getAnswer());
        if(num1-num2<=0.01 && num2-num1<=0.01){
            return true;
        }else{
            return false;
        }
            
        }
    

    }

