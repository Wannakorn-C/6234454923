
package lab9_1;


public class Customer{
    private String name,tel;
    public Customer(String name,String tel){
        this.name=name;
        this.tel=tel;
        
    }
    public void setName(String Name){
        name=Name; 
    }
    public String getName(){
        return name;
    }
    public void setTel(String Tel){
        tel=Tel;
    }
    public String getTel(){
        return tel;
    }
    public String toString(){
        return name+" tel: "+tel;
    }
}
