
package lab9_1;


public class GoldCustomer extends Customer{
    private double discount;
    public GoldCustomer(String name,String tel,double discount){
        super(name,tel);
        this.discount=discount;
    }
    public void setDiscount(double Discount){
        discount=Discount; 
    }
    public double getDiscount(){
        return discount;
    }
    public String toString(){
        return super.toString()+" discount: "+discount;
    }
}
