
package lab9_1;


public class Pizza{
    private String name;
    private double price;
    public Pizza(String name,double price){
        this.name=name;
        this.price=price;
        
    }
    public void SetName(String Name){
        name=Name;   
    }
    public String getName(){
        return name;
    }
    public void SetPrice(double Price){
        price=Price;
    }
    public double getPrice(){
        return price;
    }
    public String toString(){
        return name+" price: "+price;
    }
}
