/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;
import java.util.Calendar;
import java.util.GregorianCalendar;
/**
 *
 * @author CC
 */
public class Gregorian {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GregorianCalendar cal = new GregorianCalendar();
        cal.add(Calendar.DAY_OF_MONTH,100);
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH);
        int year = cal.get(Calendar.YEAR);
        int weekday = cal.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday+" "+dayOfMonth+" "+month+" "+year);
        GregorianCalendar myBirthday = new GregorianCalendar(2001,Calendar.FEBRUARY,15);
        myBirthday.add(Calendar.DAY_OF_MONTH,10000);
        int dayOfMonth2 = myBirthday.get(Calendar.DAY_OF_MONTH);
        int month2 = myBirthday.get(Calendar.MONTH);
        int year2 = myBirthday.get(Calendar.YEAR);
        int weekday2 = myBirthday.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday2+" "+dayOfMonth2+" "+month2+" "+year2);
    }
    
}
