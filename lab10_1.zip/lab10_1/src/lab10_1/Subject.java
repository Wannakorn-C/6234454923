
package lab10_1;


public class Subject implements Evaluation{
    private String subjName;
    private int[] score;
    public Subject(String subjName,int[] score){
        this.subjName=subjName;
        this.score=score;
        
    }
    public double evaluate(){
        double totalScore=0;
        double aveScore=0;
        for(int i=0;i<score.length;i++){
            totalScore+=score[i];
        }
        aveScore=totalScore/score.length;
        return aveScore; 
    }
    public char grade(double average){
        if(average>=70){
            return 'P';
        }else{
            return 'F';
        }
    }
    public String toString(){
        return subjName;
    }
    
}
