
package lab10_1;


public class Secretary extends Employee implements Evaluation {
    private int typingSpeed;
    private int[] score;
    public Secretary(String name,int salary,int[] score,int typingSpeed){
        super(name,salary);
        this.typingSpeed=typingSpeed;
        this.score=score;
    }
    public double evaluate(){
        double totalscore=0;
        for(int i=0;i<score.length;i++){
            totalscore+=score[i];
        } 
        return totalscore;
    }
    public char grade(double total){
        if(total>=90){
            super.setSalary(18000);
            return 'P';
        }else{
            return'F'; 
        }
    }
}
