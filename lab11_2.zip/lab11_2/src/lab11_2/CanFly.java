
package lab11_2;


public interface CanFly {
    void fly(Terrain terrain);
}
