package lab6_2;
import java.util.Scanner;
import java.util.Random;
public class Game {
    private int user=0,com=0;
    public void play(){
        while(Math.abs(user-com)!=2){
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            Scanner in = new Scanner(System.in);
            String inpu = in.next();
            if (!"0".equals(inpu) && !"1".equals(inpu) && !"2".equals(inpu) ){
                continue;
                }
            Integer input = Integer.valueOf(inpu);
            Random ran = new Random();
            int rand = ran.nextInt(3);

            String selec = null;
            switch (input){
            case 0 : selec = "ROCK";break;  
            case 1 : selec = "PAPER";break;  
            case 2 : selec = "SCISSORS";break;
            }
            System.out.println("You enter: "+selec);
            String ra = null;
            switch (rand){
            case 0 : ra = "ROCK";break;  
            case 1 : ra = "PAPER";break;  
            case 2 : ra = "SCISSORS";
            }
            System.out.println("Computer: "+ra);
            if (rand==0 && input==1 || rand==1 && input==2 || rand==2 && input==0){
                user++;
                System.out.println("You win!");
            }
            else if (input==0 && rand==1 || input==1 && rand==2 || input==2 && rand==0){
                com++;
                System.out.println("You lose!");
            }
            else{
                System.out.println("It's a tie.");
            }
        }
    System.out.println("----------------------------------------");
    if(user>com){
        System.out.println("Congrats! You win.");
        }
    else{
        System.out.println("Too bad! You lose.");
        }
    System.out.println("User Score: "+user+"\nComputer score: "+com);
    }
}