/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_2;
import static jdk.nashorn.internal.objects.NativeString.replace;
/**
 *
 * @author CC
 */
public class HollePrintor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String word="Hello, World!";
        String replace;
        replace=word.replace("o","x").replace("e", "o").replace("x","e");
        System.out.println(replace);
    }
    
}
