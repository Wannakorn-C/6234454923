/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_1;
import java.awt.Rectangle;
import java.util.Random;

/**
 *
 * @author CC
 */
public class rectanglee {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random generator = new Random();
        int x1 = generator.nextInt(49)+1;
        int y1 = generator.nextInt(49)+1;
        int w1 = generator.nextInt(49)+1;
        int h1 = generator.nextInt(49)+1;
        Rectangle r1 = new Rectangle(x1,y1,w1,h1);
       
        int x2 = generator.nextInt(49)+1;
        int y2 = generator.nextInt(49)+1;
        int w2 = generator.nextInt(49)+1;
        int h2 = generator.nextInt(49)+1;
        Rectangle r2 = new Rectangle(x2,y2,w2,h2);
       
        System.out.println(r1);
        System.out.println(r2);
       
        Rectangle r3 = r1.intersection(r2);
        System.out.println("Is the intersected rectangle empty?:"+r3.isEmpty());
// TODO code application logic here
    }
    
}
