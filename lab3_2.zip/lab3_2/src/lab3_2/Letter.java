/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_2;

/**
 *
 * @author CC
 */
public class Letter {
    public String letter;
    public String from;
    public String to;
    public Letter(String from ,String to) {
        this.from=from;
        this.to=to;
        letter="";
    } 

    public void addLine (String line){
        letter=letter+"\n"+line;
        }
    public String getText(){
        return ("Dear "+to+":\n"+letter+"\n\nSincerely,\n\n"+from);
    }
    
                
        
    
    
}
