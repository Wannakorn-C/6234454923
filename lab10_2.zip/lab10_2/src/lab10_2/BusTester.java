
package lab10_2;

import java.util.ArrayList;


public class BusTester {
     public static void main(String[] args) {
         ArrayList<Object> arr =new ArrayList<Object>();
         Hybrid h1=new Hybrid(45,1200000,600,150,1);
         arr.add(h1);
         CNGBus c1=new CNGBus(50,1000000,200,2);
         arr.add(c1);
         for(int i=0;i<arr.size();i++){
             if(arr.get(i) instanceof CNGBus){
                CNGBus c2=(CNGBus)arr.get(i);
                System.out.println("ID: "+(i+1)+"\nEmission Tier: "+c2.getEmissionTier()+"\nAccel: "+c2.getAccel());
             }else{
                 Hybrid h2=(Hybrid)arr.get(i);
                 System.out.println("ID: "+(i+1)+"\nEmission Tier: "+h2.getEmissionTier()+"\nAccel: "+h2.getAccel());
                 
             }
         }
         
     }
     
    
}
