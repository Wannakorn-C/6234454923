
package lab10_2;


public class Hybrid extends Bus implements LiquidFuel,Electric{
    private double voltage;
    private double range;
    private int emissionTier;
    public Hybrid(int capacity,double cost,double voltage,double range,int emissionTier){
        super(capacity,cost);
        this.range=range;
        this.emissionTier=emissionTier;
        if(voltage<Low_Voltage){
            this.voltage=Low_Voltage;
        }else if(voltage>High_Voltage){
            this.voltage=High_Voltage;
        }else{
            this.voltage=voltage;
        }
       
    }
    public double getRange(){
        return range;
    }
    public int getEmissionTier(){
        return emissionTier;
    }
    public double getVoltage(){
        return voltage;
    }
    public double getAccel(){
       return 4.0; 
    }
    
}
