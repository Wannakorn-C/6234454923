
package lab10_2;


public interface Electric {
    double Low_Voltage=480;
    double High_Voltage=600;
    double getVoltage();
    
}
