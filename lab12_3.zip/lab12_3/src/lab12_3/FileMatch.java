package lab12_3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;


public class FileMatch {
       ArrayList<AccountRecord> account_rec = new ArrayList<>();
       ArrayList<TransactionRecord> tran_rec = new ArrayList<>();
       private Double updateBalance = 0.0;
    public void addTransObject(){
         try{
           File file_1 = new File("D:\\NetBeansProjects\\lab12_3\\src\\lab12_3\\trans.txt");
           Scanner trans = new Scanner(file_1);
           while(trans.hasNextLine()==true){
           String ACCT = "",AMOUNT = "";
           String info  = trans.nextLine();
            for(int i =0 ; info.length()>i ; i++){
               if(info.charAt(i)!=' '){
                    ACCT+=info.charAt(i);  }
               else{
                   for(;info.length()>i+1 ; i++){
                       AMOUNT+=info.charAt(i);
                   }
                   int acctNo = Integer.parseInt(ACCT);
                   Double amount= Double.parseDouble(AMOUNT);
                   TransactionRecord object_t = new TransactionRecord(acctNo,amount);
                   tran_rec.add(object_t);
                   break;
               }
               
               }
           }        
           trans.close();
           }catch(FileNotFoundException ex) { 
               System.out.println("Error: "+ex.getMessage());  
           }        
        catch(Exception ex){ 
            System.out.println("Error: "+ex.getMessage());
        }               

    }

    public void addAccountObject() {        
        try{
           File file_2 = new File("D:\\NetBeansProjects\\lab12_3\\src\\lab12_3\\master.txt");    
           Scanner acct = new Scanner(file_2);

           while(acct.hasNextLine()==true){
           String info  = acct.nextLine();
           String[] list = info.split(" ");
           int acctNo = Integer.parseInt(list[0]);
           Double balance= Double.parseDouble(list[3]);
           String name = list[1]+" "+list[2];
           AccountRecord a = new AccountRecord (acctNo,name,balance);
           account_rec.add(a);
                     }
               acct.close();    }
        catch(FileNotFoundException ex) {
            System.out.println("Error: "+ex.getMessage()); 
        }        
        catch(Exception ex){ 
            System.out.println("Error: "+ex.getMessage());
        }               

    }

    public int accoutCnt() {
        int a = account_rec.size();
        return a; 
    }

    public int noTrans() {
        int no = 0;
        for(AccountRecord a : account_rec){
            for(TransactionRecord t : tran_rec){
                if(a.getAcctNo()==t.getAcctNo()){
                  no++;
                  break;
                }
            }
        }
        return account_rec.size()-no ;
    }
    
    public void updateinfo(){
        RandomAccessFile r = null;
        try{
             r = new RandomAccessFile("D:\\NetBeansProjects\\lab12_3\\src\\lab12_3\\newMaster.dat","rw");
            for(AccountRecord a : account_rec){
            for(TransactionRecord t : tran_rec){
                if(a.getAcctNo()==t.getAcctNo()){
                   a.combine(t); }
            }String name=a.getName();
            for(int i = name.length(); i<30;i++){
                name+="_";
            }
            r.write(a.getAcctNo());
            r.writeChars(" "+name+" ");
            r.writeDouble(a.getBalance());
            r.writeChar('\n');
            updateBalance+=a.getBalance();
        }
            
        }catch(FileNotFoundException ex) { 
            System.out.println("Error: "+ex.getMessage()); 
        }        
        catch(Exception ex){ 
            System.out.println("Error: "+ex.getMessage());
        }   
        finally{
            try{
                if(r!=null) r.close();
            }
            catch(IOException ex){
                System.out.println("Error: "+ex.getMessage());
            }   
        }
        
    }
    public double updateBalance(){

        return updateBalance;
    }
}
