
package lab4_1;
import java.util.Scanner;

public class SodaTester {
    public static void main(String[] args){
        Scanner num=new Scanner(System.in);
        System.out.print("Enter height:");
        int height=num.nextInt();
        System.out.print("Enter diameter:");
        int diameter=num.nextInt();
        SodaCan can=new SodaCan(height,diameter);
        can.Volume();
        can.Surfacearea();
        System.out.printf("Volume: %.2f\n",can.getVolume());
        System.out.printf("Surface area: %.2f\n",can.getSurfaceArea());
    }
    
}
