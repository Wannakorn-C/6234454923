/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author CC
 */
public class CashRegisterTester {
    public static void main(String[] args){
    CashRegister buy = new CashRegister(7);
    buy.recordPurchase(50.0);
    buy.recordPurchase(10.0);
    buy.recordTaxablePurchase(20.0);
    buy.enterPayment(100.0);
    System.out.println("Your change is "+buy.giveChange());
    
    
}
}
