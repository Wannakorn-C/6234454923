package lab7_2;

import java.util.Scanner;

public class MagicSquaretester {

    
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int number;
        System.out.println("\tMagic square");
        do{
            System.out.print("Enter odd number for start program: ");
            number = keyboard.nextInt();
        }while(number%2==0);
        MagicSquare play = new MagicSquare();
        play.MakeSquare(number);
        play.FillSquare();
        System.out.println(play.toString());
    }
    
}
