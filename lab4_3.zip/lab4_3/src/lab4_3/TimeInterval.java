/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;


public class TimeInterval {
    public int starttime;
    public int endtime;
    
    public TimeInterval(int start,int end){
        starttime=start;
        endtime=end;
        
    }
    public int getHours(){
        int hours=(starttime-endtime)/100;
        return hours;
    }
    public int getMinutes(){
        int minutes=starttime%100-endtime%100;
        return minutes;
    }
           
}
    

